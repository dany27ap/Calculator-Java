package com.dlegacy.calculator;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class InToPost {

    public static List<String> postfixata(ArrayList<String> exp){
        Stack<String> stiva = new Stack<>();
        List<String> postfix = new ArrayList<>();

        for(int i = 0; i < exp.size(); ++i){
            switch (exp.get(i)){
                case "+":
                case "-":
                case "*":
                case "/":
                    while((!stiva.empty()) && (priority(stiva.peek()) >= priority(exp.get(i) ))){
                        postfix.add(stiva.pop());
                    }
                    stiva.push(exp.get(i));
                    break;
                case "(":
                    stiva.push(exp.get(i));
                    break;
                case ")":
                    do{
                        postfix.add(stiva.pop());
                    }while(!(stiva.peek().equals("(")));
                    stiva.pop();
                    break;
                default:
                    postfix.add(exp.get(i));
            }

            }
            while (!stiva.empty()){
                postfix.add(stiva.pop());
            }
            return postfix;
    }

    public static int priority(String operand){
        int ok = 0;
        switch (operand){
            case "-":
            case "+":
                ok = 1;
                break;
            case "*":
            case "/":
                ok = 2;
                break;
            case "(":
                ok = 0;
                break;
        }
        return ok;
    }
}
