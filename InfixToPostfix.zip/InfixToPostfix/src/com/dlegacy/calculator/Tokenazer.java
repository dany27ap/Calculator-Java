package com.dlegacy.calculator;

import java.util.ArrayList;
import java.util.List;

public class Tokenazer {

    public static List<String> token(String string){
        List<String> tokenz = new ArrayList<>();

        String []operators = new String[] {"+", "-", "*", "/", "(", ")"};

        int index = 0;
        while (index < string.length()){
            int min = string.length();
            for(int j = 0; j < operators.length; ++j){
                int i = string.indexOf(operators[j], index);
                if(i > -1)
                    min = Math.min(min, i);
            }

            if(min < string.length()) {
                if(!string.substring(index, min).equals("")) {
                    tokenz.add(string.substring(index, min)); // adauga numere
                }
                    tokenz.add("" + string.charAt(min)); //adauga operatori
                    index = min + 1;
                }
            else {
                if(!string.substring(index).equals("")) {
                    tokenz.add(string.substring(index));
                    break;
                }
            }
        }
        return tokenz;
    }
}
