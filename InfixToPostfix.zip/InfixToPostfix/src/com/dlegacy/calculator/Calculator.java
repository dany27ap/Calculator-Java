package com.dlegacy.calculator;

import java.util.ArrayList;
import java.util.List;

import static com.dlegacy.calculator.ExpParser.result;
import static com.dlegacy.calculator.InToPost.postfixata;
import static com.dlegacy.calculator.Tokenazer.token;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class Calculator extends JFrame {
    JButton digits[] = {
            new JButton(" 0 "),
            new JButton(" 1 "),
            new JButton(" 2 "),
            new JButton(" 3 "),
            new JButton(" 4 "),
            new JButton(" 5 "),
            new JButton(" 6 "),
            new JButton(" 7 "),
            new JButton(" 8 "),
            new JButton(" 9 "),
            new JButton(" ( "),
            new JButton(" ) ")
    };

    JButton operators[] = {
            new JButton(" + "),
            new JButton(" - "),
            new JButton(" * "),
            new JButton(" / "),
            new JButton(" = "),
            new JButton(" C ")
    };

    String oper_values[] = {"+", "-", "*", "/", "=", ""};

    String value;
    char operator;

    JTextArea area = new JTextArea(3, 5);


    public static void main1(String[] args) {
        String expresie = new String("(1+2)*3+5");
        List<String> expresieSparta = token(expresie);
        List<String> expresiePost = postfixata((ArrayList<String>) expresieSparta);
        int rezultat = result((ArrayList<String>) expresiePost);
        System.out.println(rezultat);
    }

    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        calculator.setSize(230, 245);
        calculator.setTitle(" Java-Calc, PP Lab1 ");
        calculator.setResizable(false);
        calculator.setVisible(true);
        calculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public Calculator() {
        add(new JScrollPane(area), BorderLayout.NORTH);
        JPanel buttonpanel = new JPanel();
        buttonpanel.setLayout(new FlowLayout());

        for (int i=0;i<12;i++)
            buttonpanel.add(digits[i]);

        for (int i=0;i<6;i++)
            buttonpanel.add(operators[i]);

        add(buttonpanel, BorderLayout.CENTER);
        area.setForeground(Color.BLACK);
        area.setBackground(Color.WHITE);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(false);

        for (int i=0;i<10;i++) {
            int finalI = i;
            digits[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {
                    area.append(Integer.toString(finalI));
                }
            });
        }

        for (int i=10;i<12;i++) {
            int finalI = i;
            digits[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {
                    area.append(digits[finalI].getText().replace(" ", ""));
                }
            });
        }

        for (int i=0;i<6;i++){
            int finalI = i;
            operators[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {
                    if (finalI == 5)
                        area.setText("");
                    else if (finalI == 4) {
                        String expresie = area.getText().replace(" ", "");
                        int rezultat;
                        List<String> expresieSparta = token(expresie);
                        List<String> expresiePost = postfixata((ArrayList<String>) expresieSparta);
                        rezultat = result((ArrayList<String>) expresiePost);
                        area.setText(String.valueOf(rezultat));
                    } else {
                        area.append(oper_values[finalI]);
                        operator = oper_values[finalI].charAt(0);
                    }
                }
            });
        }
    }
}